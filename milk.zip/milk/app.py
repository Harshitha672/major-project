# Importing necessary libraries
from flask import Flask, render_template, request
import joblib
import pandas as pd

# Load the trained model
model = joblib.load('random_forest_model.pkl')

# Initialize Flask app
app = Flask(__name__)

# Define a route for the home page
@app.route('/')
def home():
    return render_template('index.html')

# Define a route for prediction
@app.route('/predict', methods=['POST'])
def predict():
    # Extract feature values from the form
    ph = float(request.form['ph'])
    temperature = float(request.form['temperature'])
    taste = float(request.form['taste'])
    odor = float(request.form['odor'])
    fat = float(request.form['fat'])
    turbidity = float(request.form['turbidity'])
    colour = float(request.form['colour'])
    
    # Create a DataFrame for the input features
    input_data = pd.DataFrame([[ph, temperature, taste, odor, fat, turbidity, colour]],
                              columns=['pH', 'Temperature', 'Taste', 'Odor', 'Fat', 'Turbidity', 'Colour'])
    
    # Make prediction
    prediction = model.predict(input_data)[0]
    
    # Return the predicted grade
    return render_template('results.html', prediction=prediction)

# Run the app
if __name__ == '__main__':
    app.run(debug=True)
